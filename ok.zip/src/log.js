const log = (...args) => console.log(`[${ new Date().toISOString() }]`, ...args)

const dbg = Object.fromEntries(Array(5)
  .fill()
  .map((v, i) => i + 1)
  .map(level => [
    level,
    level <= Number(process.env.DEBUG_LEVEL)
      ? log
      : () => null,
  ]))

const debug = level => dbg[ level ]
const info = log
const error = log

module.exports = {
  debug,
  info,
  error,
}
