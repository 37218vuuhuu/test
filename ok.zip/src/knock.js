const { createConnection } = require('net')

const knock = (host, port = 22, timeout = 3e3) => new Promise((resolve, reject) => {
  const socket = createConnection({
    host,
    port,
    timeout,
  })
  const timer = setTimeout(
    () => {
      reject(Error(`connection to ${ host }:${ port } has timed out`))
      socket.destroy()
    },
    timeout,
  )

  socket.on('connect', () => {
    clearTimeout(timer)
    resolve(true)
    socket.destroy()
  })
  socket.on('error', error => {
    clearTimeout(timer)
    reject(error)
    socket.destroy()
  })
})

module.exports = knock
