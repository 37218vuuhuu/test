const knock = require('./knock')
const { debug } = require('./log')

const select = async (list, size, timeout) => {
  const selected = []
  const knocked = []
  let remaining
  let cursor = 0

  debug(3)('select', size, 'out of', list.length, 'entries')

  // knock servers until we have `size` responsive servers
  while (
    (remaining = size - selected.length) > 0
      && cursor < list.length
  ) {
    // to increase the chance of getting enough responses in one iteration,
    // the number of servers being knocked at a time is larger than
    //   the remaining
    const count = (remaining * 2) + (remaining ** 0.5) + 2
    const slice = list.slice(cursor, cursor += count)
    const results = slice.map((entry, i) => knock(entry.host, 22, timeout)
      .catch(() => false)
      .then(success => [ success, entry, i ]))
    const resolved = []

    debug(2)('knock', count, 'hosts', ...slice.map(({ host }) => host))

    knocked.push(...results)

    while (
      resolved.length < results.length
      && selected.length < size
    ) {
      // individually wait for fastest servers
      const [ success, entry, i ] = await Promise.race(results.filter((v, i) => !resolved.includes(i)))

      resolved.push(i)

      if (success) {
        selected.push(entry)
      }
    }
  }

  debug(1)('selected', selected.length, 'hosts', ...selected.map(({ host }) => host))

  return [ selected, knocked ]
}

module.exports = select
