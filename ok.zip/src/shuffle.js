const shuffle = list => list.sort(() => Math.random() - 0.5)

module.exports = shuffle
